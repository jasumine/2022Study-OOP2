#pragma once
#include <iostream>
#include "Utils.h"
#include "GameObject.h"
#include "Player.h"
#include "Enemy.h"
#include "Screen.h"

using namespace std;

class GameManager
{
private:


public:
	virtual ~GameManager() { }


};

